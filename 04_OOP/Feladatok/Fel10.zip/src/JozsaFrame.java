import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;

public class JozsaFrame extends JFrame {
    private JPanel mainPanel;
    private JozsaCanvas jCanvas;
    private JPanel buttonPanel;
    public static JToggleButton drawPixel;
    public static JToggleButton drawLine;

    public JozsaFrame() throws IOException {
        mainPanel = new JPanel();
        mainPanel.setLayout(new BorderLayout());
        mainPanel.setBounds(10, 10, 500, 500);

        drawPixel = new JToggleButton();
        //drawPixel.setBounds(new Rectangle(100,100));
        drawPixel.setMargin(new Insets(0, 0, 0, 0));
        drawPixel.setIcon(new ImageIcon(this.getClass().getResource("img/iconPixel.png")));
        drawPixel.setSelected(true);
        drawPixel.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (drawPixel.isSelected()) {
                    drawPixel.setSelected(true);
                    drawLine.setSelected(false);
                } else {
                    drawPixel.setSelected(false);
                    drawLine.setSelected(true);
                }
            }
        });

        drawLine = new JToggleButton();
        drawLine.setMargin(new Insets(0, 0, 0, 0));
        drawLine.setIcon(new ImageIcon(this.getClass().getResource("img/iconLine.png")));
        drawLine.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (drawLine.isSelected()) {
                    drawLine.setSelected(true);
                    drawPixel.setSelected(false);
                    jCanvas.clearCanvas();
                } else {
                    drawLine.setSelected(false);
                    drawPixel.setSelected(true);
                }
            }
        });

        buttonPanel = new JPanel();
        buttonPanel.setLayout(new GridLayout(20, 1));
        buttonPanel.add(drawLine);
        buttonPanel.add(drawPixel);

        mainPanel.add(buttonPanel, BorderLayout.WEST);

        jCanvas = new JozsaCanvas();
        mainPanel.add(jCanvas, BorderLayout.CENTER);

        this.setContentPane(mainPanel);
    }

}

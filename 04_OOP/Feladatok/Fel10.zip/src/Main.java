import javax.swing.*;
import java.io.IOException;

public class Main {
    public static void main(String[] args) throws IOException {
        JozsaFrame canvas = new JozsaFrame();
        canvas.setBounds(10, 10, 500, 500);
        canvas.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        canvas.setVisible(true);
    }
}
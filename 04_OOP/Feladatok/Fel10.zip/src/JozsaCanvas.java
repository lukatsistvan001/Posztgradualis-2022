import javax.swing.event.MouseInputAdapter;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;

public class JozsaCanvas extends Canvas {
    private Integer x1;
    private Integer y1;
    private Integer x2;
    private Integer y2;

    private ArrayList<Integer> xDragged;
    private ArrayList<Integer> yDragged;

    public JozsaCanvas() {
        setBackground(Color.LIGHT_GRAY);
        x1 = null;
        y1 = null;
        x2 = null;
        y2 = null;
        xDragged = new ArrayList<>();
        yDragged = new ArrayList<>();

        addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                super.mousePressed(e);
                if (JozsaFrame.drawLine.isSelected()) {
                    if (x1 == null | y1 == null) {
                        x1 = e.getX();
                        y1 = e.getY();
                    } else {
                        x2 = e.getX();
                        y2 = e.getY();
                        repaint();
                    }
                }
            }

        });

        this.addMouseMotionListener(new MouseAdapter() {
            @Override
            public void mouseDragged(MouseEvent e) {
                if (JozsaFrame.drawPixel.isSelected()) {
                    xDragged.add(e.getX());
                    yDragged.add(e.getY());
                    repaint();
                }
            }
        });
    }

    public void clearCanvas() {
        xDragged.clear();
        yDragged.clear();
    }

    @Override
    public void paint(Graphics g) {
        g.setColor(Color.BLACK);
        if (JozsaFrame.drawLine.isSelected()) {
            if (this.x1 != null && this.x2 != null && this.y1 != null && this.y2 != null) {
                g.drawLine(x1, y1, x2, y2);
                x1 = null;
                y1 = null;
            }
        }

        if (JozsaFrame.drawPixel.isSelected()) {
            if (!xDragged.isEmpty()) {
                for (int i = 0; i < xDragged.size() - 1; i++) {
                    g.drawLine(xDragged.get(i), yDragged.get(i), xDragged.get(i + 1), yDragged.get(i + 1));
                }
            }

        }
    }
}

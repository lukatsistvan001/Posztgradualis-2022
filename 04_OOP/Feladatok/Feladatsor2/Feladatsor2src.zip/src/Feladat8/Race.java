package Feladat8;

public class Race {
    public static void main(String[] args) {
        RaceController rc = new RaceController(0);
        rc.initRace(0);
    }
}

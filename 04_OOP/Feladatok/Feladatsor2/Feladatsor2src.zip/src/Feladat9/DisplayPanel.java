package Feladat9;

import javax.swing.*;

public class DisplayPanel extends JFrame {

    private String displaytext;

    public DisplayPanel(String displaytext){
        this.displaytext = displaytext;
        JPanel panel = new
    }
}

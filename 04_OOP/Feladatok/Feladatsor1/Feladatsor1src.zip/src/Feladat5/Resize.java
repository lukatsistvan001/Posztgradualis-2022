package Feladat5;

public interface Resize {

    public void resize(Dimension dimension);
}
package Feladat5;

public class Dimension {

    protected double length;
    protected double width;

    public Dimension(double length, double width) {
        this.length = length;
        this.width = width;
    }
}
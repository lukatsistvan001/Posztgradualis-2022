package Feladat6.collection;

import Feladat6.core.Student;

public interface StudentIterator {

    public boolean hasMoreElements();

    public Student nextElement();

}

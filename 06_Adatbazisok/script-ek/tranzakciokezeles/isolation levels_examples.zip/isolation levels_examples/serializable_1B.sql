﻿--a repeatable_read_2B.sql fájlban szereplő műveletet hajtjuk végre újra

insert into Students
    values( 1600,'StName',621)
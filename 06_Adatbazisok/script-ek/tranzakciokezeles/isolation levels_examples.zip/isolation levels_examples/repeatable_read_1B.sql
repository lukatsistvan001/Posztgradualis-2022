UPDATE Students 
SET GID=524
where StID = 1581
--alapertelmezett elkulonitesi szint: read committed
BEGIN TRANSACTION
SELECT * 
FROM Teachers 
WAITFOR DELAY '00:00:05'
COMMIT
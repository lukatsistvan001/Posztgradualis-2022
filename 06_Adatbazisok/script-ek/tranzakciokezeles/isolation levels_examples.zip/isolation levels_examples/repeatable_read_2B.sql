insert into Students
    values( 1600,'StName',621)
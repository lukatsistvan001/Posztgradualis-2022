set transaction isolation level repeatable read
begin transaction
select * from Students 
waitfor delay '00:00:05'
select * from Students 
rollback transaction
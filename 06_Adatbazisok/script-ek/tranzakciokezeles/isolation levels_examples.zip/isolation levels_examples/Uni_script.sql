﻿DROP TABLE Teach
DROP TABLE Teachers
DROP TABLE Students
DROP TABLE Groups
GO


CREATE TABLE Groups(
	GID INT NOT NULL,
	GroupSize INT)

ALTER TABLE Groups
ADD CONSTRAINT GID_PK PRIMARY KEY(GID)

ALTER TABLE Groups
	ADD CONSTRAINT GroupSize_Default DEFAULT 0 FOR GroupSize
	
ALTER TABLE Groups
	ADD CONSTRAINT GroupSize_Check CHECK (GroupSize BETWEEN 0 AND 5) --azért, hogy könnyebb legyen a CHECK megszorítást ellenőrizni

CREATE TABLE Students(
	StID INT NOT NULL,
	SName VARCHAR(30) NOT NULL,
	GID INT
)

ALTER TABLE Students
	ADD CONSTRAINT StID_PK PRIMARY KEY(StID)

ALTER TABLE Students
	ADD CONSTRAINT GID_FK FOREIGN KEY(GID) REFERENCES Groups(GID)

GO

CREATE TABLE Teachers(
	TID INT NOT NULL IDENTITY(1,1),
	TName VARCHAR(30) NOT NULL,
	Salary INT)
		
ALTER TABLE Teachers
ADD CONSTRAINT TID_PK PRIMARY KEY(TID)

CREATE TABLE Teach(
	TID INT NOT NULL,
	GID INT NOT NULL)
		
ALTER TABLE Teach
	ADD CONSTRAINT TTID_FK FOREIGN KEY(TID) REFERENCES Teachers(TID)
	
ALTER TABLE Teach	
	ADD CONSTRAINT TGID_FK FOREIGN KEY(GID) REFERENCES Groups(GID)

ALTER TABLE Teach
	ADD CONSTRAINT Teach_PK PRIMARY KEY(TID, GID)

INSERT INTO Groups(GID) VALUES	(521),
								(522),
								(523),
								(524),
								(621)

INSERT INTO Students VALUES (1581, 'DName1', 521),
							(1582, 'DName2', 521),
							(1583, 'DName3', 521),
							(1584, 'DName4', 521),
							(1585, 'DName5', 521),
							(1586, 'DName6', 522),
							(1587, 'DName7', 523),
							(1588, 'DName8', 523),
							(1589, 'DName9', 524),
							(1590, 'DName10', 524)

INSERT INTO Teachers(TName, Salary) VALUES ('TName1', 1500),
										   ('TName2', 2500),
										   ('TName3', 2000),
										   ('TName4', 3000),
										   ('TName5', 1850),
										   ('TName6', 2250),
										   ('TName7', 1450),
										   ('TName8', 1250),
										   ('TName9', 2000),
										   ('TName10', 2250)


INSERT INTO Teach VALUES (1, 521), (1, 522), (1, 523),
						 (2, 521), (2, 523), (2, 524), (2, 621),
						 (3, 521), (3, 522), (3, 523), (3, 524), (3, 621)
									
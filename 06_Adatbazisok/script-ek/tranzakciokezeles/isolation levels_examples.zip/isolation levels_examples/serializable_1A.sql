﻿--a repeatable_read_2A.sql fájlban szereplő műveleteket hajtjuk végre újra, de az elkülönítési szintet serializable-re állítjuk

set transaction isolation level serializable
begin transaction
select * from Students 
waitfor delay '00:00:05'
select * from Students 
rollback transaction
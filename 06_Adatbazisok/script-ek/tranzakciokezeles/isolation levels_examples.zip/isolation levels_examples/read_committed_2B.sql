SELECT * 
FROM Teachers 
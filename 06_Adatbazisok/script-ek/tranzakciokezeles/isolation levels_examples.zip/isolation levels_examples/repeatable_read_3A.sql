--megegyezik az 1A-val
set transaction isolation level repeatable read
begin transaction
select * from Students where StID in(1581,1582)
waitfor delay '00:00:05'
select * from Students where StID in(1581,1582)
rollback transaction
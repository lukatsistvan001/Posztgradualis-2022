set transaction isolation level serializable
begin transaction
select * from Students where StID between 1581 AND 1601
waitfor delay '00:00:05'
select * from Students where StID between 1581 AND 1601
rollback transaction
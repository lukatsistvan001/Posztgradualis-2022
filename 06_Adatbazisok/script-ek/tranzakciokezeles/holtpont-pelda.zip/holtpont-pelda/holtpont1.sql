BEGIN TRANSACTION

UPDATE Students 
SET GID=521
where StID = 1581

waitfor delay '00:00:05'

UPDATE Teachers 
SET Salary=1100 
WHERE TID=1

COMMIT